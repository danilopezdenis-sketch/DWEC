
// Modal carrito de la compra
document.getElementById("btnCarrito").onclick = () => {
    document.getElementById("modalCarrito").style.display = "flex";
}

document.querySelector('#modalCarrito .close').onclick = () => {

    document.getElementById("modalCarrito").style.display = "none";

}


// Detalles del producto
const productos = document.querySelectorAll(".producto");

productos.forEach(p => {

    p.addEventListener('click', e =>{

        if(e.target.classList.contains("btnDetalles")){
            const img = p.querySelector("img").src;
            const nombre = p.querySelector("h3").textContent;
            const precio = p.querySelector("p").textContent;
            const modal = document.getElementById("modalDetalles");
            const content = modal.querySelector(".modal-content");
            content.innerHTML = `
                <span class="close">&times;</span>
                <img src="${img}" alt="${nombre}">
                <h3>${nombre}</h3>
                <p>${precio}</p>
            `;
            modal.style.display = "flex";
               
            const spanClose = content.querySelector(".close");
            spanClose.onclick = () => {
                modal.style.display = "none";
        }
    }

    })


})



// Modal usuario

const botonUsuario = document.getElementById("btnUsuario");

botonUsuario.onclick = () => {
    document.getElementById("modalLogin").style.display = "flex";
}
document.querySelector('#modalLogin .close').onclick = () => {

    document.getElementById("modalLogin").style.display = "none";}


